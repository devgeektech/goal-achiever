<!DOCTYPE html>
<html>
<head>
 <title>Islamic Online Learning Centre</title>
</head>
<body>
 
 <p>Username: {{$contact['name'] ?? ""}}</p>
 <p>Email : {{$contact['email'] ?? ""}}</p>
 <p>Description : {{$contact['comment'] ?? ""}}</p>
</body>
</html> 
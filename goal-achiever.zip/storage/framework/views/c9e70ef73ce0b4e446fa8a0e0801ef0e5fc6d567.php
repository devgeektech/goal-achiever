<?php $__env->startSection('content'); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

           <?php echo $__env->make('admin.layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Student Info</h1>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Student Info</h6>
                            <a href="<?php echo e(route('admin.students.index')); ?>"class="btn btn-primary" style="float: right;">Back</a>
                        </div>
                        <div class="card-body">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label for="forName">Name</label>
                                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e($student->name); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forEmail">Email</label>
                                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e($student->email); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forProfileImage">Profile Image</label><br>
                                    <img src="<?php if($student->profile_image): ?><?php echo e(Storage::url($student->profile_image)); ?> <?php else: ?> <?php echo e(URL::to('/admin/img/undraw_profile.svg')); ?> <?php endif; ?>" height="100px" width="100px">
                                </div>
                                <div class="form-group">
                                    <label for="forGoalsAchieved">Goals Achieved</label>
                                    <input type="text" class="form-control" name="goal_achieved" id="goal_achieved" value="<?php echo e($student->id+2); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forGoalsTaken">Paricipated in Goals</label>
                                    <input type="text" class="form-control" name="goal_taken" id="goal_taken" value="<?php echo e($student->id+5); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forGoalsPending">Goals Pending</label>
                                    <input type="text" class="form-control" name="goal_pending" id="goal_pending" value="<?php echo e(($student->id+5) - ($student->id+2)); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

           
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/goal-achiever/resources/views/admin/student/info.blade.php ENDPATH**/ ?>
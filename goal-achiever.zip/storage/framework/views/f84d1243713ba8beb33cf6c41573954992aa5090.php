<!DOCTYPE html>
<html>
<head>
 <title>Islamic Online Learning Centre</title>
</head>
<body>
 
 <p>Username: <?php echo e($contact['name'] ?? ""); ?></p>
 <p>Email : <?php echo e($contact['email'] ?? ""); ?></p>
 <p>Description : <?php echo e($contact['comment'] ?? ""); ?></p>
</body>
</html> <?php /**PATH /opt/lampp/htdocs/goal-achiever/resources/views/emails/contactus.blade.php ENDPATH**/ ?>
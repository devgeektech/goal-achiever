<?php $__env->startSection('content'); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

           <?php echo $__env->make('admin.layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
     
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Edit Goal</h1>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Edit Goal</h6>
                            <a href="<?php echo e(route('admin.goals.index')); ?>"class="btn btn-primary" style="float: right;">Back</a>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.goals.update',$goal->id)); ?>" method="POST" enctype="multipart/form-data"> 
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="subject_id" id="subject_id" value="">
                                <input type="hidden" name="unit_id" id="unit_id" value="">
                                <div class="row goalWrap">
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                  <div class="form-group">
                                    <strong>Subject:</strong>
                                    <select class="form-select form-control"  name="subject" id="subject">
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($goal->subject_id == $subject->id ? 'selected':''); ?> value="<?php echo e($subject->id); ?>"><?php echo e($subject->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    </select>
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <div class="form-group">
                                      <strong>Unit:</strong>
                                      <select class="form-select form-control"  name="unit" id="unit">
                                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($goal->unit_id == $unit->id ? 'selected':''); ?> value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    </select>
                                     <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <div class="form-group">
                                      <strong>Topic:</strong>
                                      <select class="form-select form-control"  name="topic" id="topic">
                                        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($goal->topic_id == $topic->id ? 'selected':''); ?> value="<?php echo e($topic->id); ?>"><?php echo e($topic->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    </select>
                                     <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <label class="form-label d-flex" for="customFile">Document</label>
                                    <?php $__currentLoopData = $media_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group videoImgBlock" style="display:inline-flex;">
                                            <i class="fas fa-edit document_edit"  data-type="<?php echo e($media->type); ?>" data-id="<?php echo e($media->id); ?>" style="cursor:pointer"></i>
                                                <img src="<?php echo e(Storage::url($media->media) ?? URL::to('/images/dummy.jpg')); ?>" height="100" widht="100">
                                           
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="file" class="form-control" id="document" name="document[]" multiple accept="image/png, image/gif, image/jpeg"/>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <label class="form-label d-flex" for="customFile">Video</label>
                                    <?php $__currentLoopData = $media_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid_media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group videoImgBlock" style="display:inline-flex;">
                                            <i class="fas fa-edit document_edit" data-type="<?php echo e($vid_media->type); ?>" data-id="<?php echo e($vid_media->id); ?>" style="cursor:pointer"></i>
                                            <video width="320" height="240" controls>
                                                <source src="<?php echo e(Storage::url($vid_media->media) ?? URL::to('/images/dummy.jpg')); ?>" type="video/mp4">
                                              </video>
                                             
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                        <input type="file" class="form-control" id="video" name="video[]" multiple accept="video/mp4,video/x-m4v,video/*"/>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <label class="form-label d-flex" for="customFile">Exam Document</label>
                                    <?php $__currentLoopData = $exam_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam_doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group videoImgBlock" style="display:inline-flex;">
                                        <i class="fas fa-edit document_edit" data-type="<?php echo e($exam_doc->type); ?>" data-id="<?php echo e($exam_doc->id); ?>" style="cursor:pointer"></i>
                                        <img src="<?php echo e(Storage::url($exam_doc->media) ?? URL::to('/images/dummy.jpg')); ?>" height="100" widht="100">
                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <input type="file" class="form-control" id="exam_document" name="exam_document[]" multiple accept="image/png, image/gif, image/jpeg"/>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <div class="form-group">
                                        <strong>Goal End Date:</strong>
                                        <input type="date" name="end_date" value="<?php echo e($goal->end_date ?? ""); ?>" class="form-control" placeholder="Goal End Date"> <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <div class="form-group">
                                        <strong>Creator Name:</strong>
                                        <input type="text" name="creator_name" value="<?php echo e($goal->creator_name ?? ""); ?>" class="form-control" placeholder="Creator name"> <?php $__errorArgs = ['creator_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 mb-3">
                                    <div class="form-group">
                                        <strong>Instructor Name:</strong>
                                        <input type="text" name="instructor_name" value="<?php echo e($goal->instructor_name ?? ""); ?>" class="form-control" placeholder="Instructor name"> <?php $__errorArgs = ['instructor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary ml-3">Update</button>
                              </div>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

           
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    <!-- Modal -->
    <div class="modal fade" id="add_doc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Update Document</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.goals.update-doc')); ?>" method="post" enctype="multipart/form-data"> 
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" name="doc_id" id="doc_id" value="">
                        <input type="hidden" name="doc_type" id="doc_type" value="">
                        <label class="form-label"  for="goalDocuments">Documents</label>
                        <input type="file" class="form-control"  name="document" accept="image/png, image/gif, image/jpeg,video/mp4,video/x-m4v,video/* "/>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
            
        </div>
        </div>
    </div>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
   
   <?php $__env->stopSection(); ?>
   <?php $__env->startPush('js'); ?>
   <script>
    let get_units = "<?php echo e(route('admin.goals.get_units')); ?>";
    let get_topics = "<?php echo e(route('admin.goals.get_topics')); ?>";
    </script>
    <script src="<?php echo e(URL::to('/admin/js/all.js')); ?>"></script>
   <?php $__env->stopPush(); ?>
   
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/goal-achiever/resources/views/admin/goals/edit.blade.php ENDPATH**/ ?>
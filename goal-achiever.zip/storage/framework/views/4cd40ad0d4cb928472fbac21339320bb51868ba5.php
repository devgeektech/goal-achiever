<?php $__env->startSection('content'); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

           <?php echo $__env->make('student.layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Goal Info</h1>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Goal Info</h6>
                            <a href="<?php echo e(route('student.goals.index')); ?>"class="btn btn-primary" style="float: right;">Back</a>
                        </div>
                        <div class="card-body">
                            <div class="row goalWrap">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group" >
                                    <label for="forSubject">Subject</label>
                                    <input type="text" class="form-control" value="<?php echo e($goal->subject->title); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forUnit">Unit</label>
                                    <input type="text" class="form-control" value="<?php echo e($goal->unit); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forTopic">Topic</label>
                                    <input type="text" class="form-control" value="<?php echo e($goal->topic); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="forGoalEndDate">Goal End Date</label>
                                    <input type="text" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($goal->end_date)->format('j F, Y')); ?>" readonly>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label class="form-group d-flex" for="forUnit">Documents</label>
                                    <?php $__currentLoopData = $media_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group videoImgBlock" style="display:inline-flex; cursor:pointer;">
                                        <img src="<?php echo e(Storage::url($media->media) ?? URL::to('/images/dummy.jpg')); ?>" height="100" widht="100">
                                        <i class="fa fa-download" aria-hidden="true"></i>
                                        </div>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label class="form-group d-flex" for="forUnit">Videos</label>
                                    <?php $__currentLoopData = $media_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid_media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group videoImgBlock" style="display:inline-flex;cursor:pointer;">
                                            <video width="320" height="240" controls>
                                                <source src="<?php echo e(Storage::url($vid_media->media) ?? URL::to('/images/dummy.jpg')); ?>" type="video/mp4">
                                              </video>
                                              <i class="fa fa-download" aria-hidden="true"></i>
                                        </div>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label class="form-group d-flex" for="forUnit">Exam Documents</label>
                                    <?php $__currentLoopData = $exam_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam_doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group videoImgBlock" style="display:inline-flex;cursor:pointer;">
                                            <img src="<?php echo e(Storage::url($exam_doc->media) ?? URL::to('/images/dummy.jpg')); ?>" height="100" widht="100">
                                            <i class="fa fa-download" aria-hidden="true"></i>
                                        </div>
 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary ml-3">Buy</button>
                        </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

           
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/goal-achiever/resources/views/student/goals/info.blade.php ENDPATH**/ ?>